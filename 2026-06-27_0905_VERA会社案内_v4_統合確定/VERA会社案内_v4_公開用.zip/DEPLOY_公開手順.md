# VERA会社案内 v4（統合確定版）｜ 公開手順（Netlify Drop・約30秒）

このフォルダ（`_publish`）が、そのまま公開できる「完成一式」です。入口は `index.html`。

## 手順（30秒）
1. ブラウザで **https://app.netlify.com/drop** を開く
2. **この `_publish` フォルダごと**、画面にドラッグ＆ドロップ
3. 数秒で公開URL（例：`https://random-name-1234.netlify.app`）が出る
4. 「**Site settings → Change site name**」で名前を **`vera-company`** に変更
   → URLが **https://vera-company.netlify.app** になります
5. そのURLを `LINE送付文.txt` に貼って送る

## 中身（参照しているファイル）
- `index.html` … 会社案内本体（入口）
- `vera_logo_2color.svg` … 表紙の2色ロゴ（赤×紺）
- `vera_logo_mono_navy.svg` … CONCEPTの紺シンボル
- `vera_logo_white.svg` … フッターの白抜きロゴ
- `sign_morio_white.png` … 代表メッセージの直筆サイン（白・背景透過）

## このv4で確定したこと（v2/v3の統合）
- 思想セクションを充実（背骨／二階建ての土台／価値の地図／五本の柱／STORY）＝v3由来
- ブランド色＝**台紙は白、フレーム・罫・ドットはコンタクト赤で統一**／金は代表メッセージ見出しに“差し色”で少しだけ
- 防災（VERAハウス）＝**強め**（「完全無傷を証明」）＋出典注記で主語＝提携メーカー実績を明記
- 直筆サイン＝最新画像・白透過PNG（印刷/PDFでも確実）
- 四つ葉 A＝源・R＝本物(中身)に訂正、MISSIONに「選ぶ自由まで」、表紙第二タグ「縛らない。だから、選ばれる。」

## 注意
- `noindex` 設定済み（検索に出ません＝商談相手・身内に見せる用）。機密は載せていません。
- VERAハウス（VERA House）の商標は出願準備中。®や「登録商標」は付けないこと。
- 差し替えは、ファイルを直して**同じサイトに再ドロップ（上書き）**すればURLそのまま。
- 印刷/PDF配布は、親フォルダの `VERA会社案内_v4.pdf`（A4・全10ページ）を使用。
